#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <queue>
using namespace std;

static int readCSV(const string& filename, string name, string countryCode) {
    ifstream file(filename);
    string line, word;

    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return 1;
    }

    while (getline(file, line)) {
        stringstream ss(line);
            if (line.find(countryCode) == line.find(word) && line.find(name) != string::npos) {
                while (getline(ss, word, ',')) {

                    if (word != countryCode && word != name) {
                        cout << "Population: " << word << endl;
                    }

                }
                break;
            }
        }
    file.close();
    return 0;
}



static vector<vector<string>> CacheCSV(const string& filename,string name, string countryCode) {
    ifstream file(filename);
    vector<vector<string>> data;
    string line, word;
    queue<vector<vector<string>>> q;


    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return data;
    }
    while (getline(file, line)) {
        stringstream ss(line);
        vector<string> row;

        while (getline(ss, word, ',')) {
            row.push_back(word);
        }
        data.push_back(row);
        q.push(data);

        if (q.size() <= 10) {

            if (countryCode == data[0][0] && name == data[0][1]) {
                cout << "Population: " << data[0][2] << endl;
                return data;
            }
            if (q.size() >= 10) {
                q.pop();
            }
            data.clear();
        }
    }


    file.close(); //close and return data
    return data;
}
// TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
int main() {

    string cityName;
    string countryCode;
    while (true) {
        cout<< "enter a city name: " << endl;
        getline(cin, cityName);
        cout<< "enter a country code: " << endl;
        getline(cin, countryCode);

        if (countryCode == cityName) {
            cout<<"cannot have countryCode and cityName be the same!";
            return 0;
        }


        CacheCSV("world_cities.csv",cityName,countryCode);
        readCSV("world_cities.csv",cityName,countryCode);

    }
}

// TIP See CLion help at <a
// href="https://www.jetbrains.com/help/clion/">jetbrains.com/help/clion/</a>.
//  Also, you can try interactive lessons for CLion by selecting
//  'Help | Learn IDE Features' from the main menu.