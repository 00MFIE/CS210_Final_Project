#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <queue>
#include <random>
#include <ctime>
#include <list>
#include <unordered_map>
using namespace std;

struct Node { //school struct includes name,address,city,state,country, and a pointer to the next one
    string CountryCode;
    string CityName;
    string Population;

    Node* next;
};

static vector<vector<string>> CacheFIFO(const string& filename,string name, string countryCode) {
    ifstream file(filename);
    vector<vector<string>> data;
    string line, word;
    queue<vector<vector<string>>> q;


    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return data;
    }
    while (getline(file, line)) {
        stringstream ss(line);
        vector<string> row;

        while (getline(ss, word, ',')) {
            row.push_back(word);
        }
        data.push_back(row);
        q.push(data);

        if (countryCode == data[0][0] && name == data[0][1]) {
            cout << "Population: " << data[0][2] << endl;
            return data;
        }
        if (q.size() >= 10) {
            q.pop();
        }
        data.clear();
    }


    file.close(); //close and return data
    return data;
}

static vector<vector<string>> CacheRR(const string& filename,string name, string countryCode) {
    ifstream file(filename);
    vector<vector<string>> data;
    string line, word;
    Node element;
    list<Node> cache;

    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return data;
    }
    while (getline(file, line)) {
        stringstream ss(line);
        vector<string> row;

        while (getline(ss, word, ',')) {
            row.push_back(word);
        }
        data.push_back(row);

        element.CountryCode = data[0][0];
        element.CityName = data[0][1];
        element.Population = data[0][2];
        cache.push_front(element);


        int num = rand() % 10;
        list<Node>::iterator at = cache.begin();
        advance(at,num);
        if (countryCode == at->CountryCode && name == at->CityName) {
            cout << "Population: " << at->Population << endl;
            return data;
        }
        if (cache.size()>=10) {
            cache.erase(at);
        }
        data.clear();
    }


    file.close(); //close and return data
    return data;
}

static vector<vector<string>> CacheLFU(const string& filename,string name, string countryCode) {
    ifstream file(filename);
    vector<vector<string>> data;
    string line, word;
    Node element;
    list<Node> cache;

    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        return data;
    }
    while (getline(file, line)) {
        stringstream ss(line);
        vector<string> row;

        while (getline(ss, word, ',')) {
            row.push_back(word);
        }
        data.push_back(row);

        element.CountryCode = data[0][0];
        element.CityName = data[0][1];
        element.Population = data[0][2];
        cache.push_front(element);

        if (countryCode == data[0][0] && name == data[0][1]) {
            cout << "Population: " << data[0][2] << endl;
            return data;
        }

        if (cache.size()>=10) {
            list<Node>::iterator at = cache.begin();
            for (int i=0; i<10; i++) { //go through cache
                int count = 0;
                int maxcount = 0;

                list<Node>::iterator first = cache.begin();
                advance(first,i); //move to spot
                for (int j=0; j<10; j++) {
                    list<Node>::iterator second = cache.begin();
                    advance(second,j); //move to second spot
                    if (first->CityName == second->CityName) { //compare if there is match
                        count ++; //increase counter
                    }
                    if (maxcount < count) { //check if its bigger than the last frequent element
                        maxcount = count; //update
                        advance(at,j); //note where element is
                    }
                }
                cache.erase(at); //erase it
            }

        }
        data.clear();
    }


    file.close(); //close and return data
    return data;
}

int main() {

    string cityName;
    string countryCode;
    int choice = 0;
    while (true) {
        cout<< "enter a city name: " << endl;
        getline(cin, cityName);
        cout<< "enter a country code: " << endl;
        getline(cin, countryCode);
        cout << "which cache method?:" << endl;
        cout << "1. FIFO" << endl;
        cout << "2. RR" << endl;
        cout << "3. LFU" << endl;
        cin >> choice;

        if (countryCode == cityName) {
            cout<<"cannot have countryCode and cityName be the same!";
            return 0;
        }

        if (choice == 1) {
            CacheFIFO("world_cities.csv",cityName,countryCode);
        }
        else if (choice == 2) {
            CacheRR("world_cities.csv",cityName,countryCode);
        }
        else if (choice == 3) {
            CacheLFU("world_cities.csv",cityName,countryCode);
        }



    }
}
// TIP See CLion help at <a
// href="https://www.jetbrains.com/help/clion/">jetbrains.com/help/clion/</a>.
//  Also, you can try interactive lessons for CLion by selecting
//  'Help | Learn IDE Features' from the main menu.